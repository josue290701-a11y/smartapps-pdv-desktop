// SmartApps PDV - app de escritorio (Electron 22, compatible con Windows 7 SP1)
const { app, BrowserWindow, ipcMain, Menu, dialog, shell, session } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');

// Puerto FIJO: el origen (http://127.0.0.1:47831) no debe cambiar nunca,
// porque ahí se guardan la sesión de Firebase y los datos locales de la tienda.
const PUERTO = 47831;
const RAIZ = path.join(__dirname, 'app');
const MODO_DEV = process.argv.includes('--dev');

// Si la pantalla sale en blanco o con fallas en una PC vieja, abre la app con --sin-gpu
if (process.argv.includes('--sin-gpu')) app.disableHardwareAcceleration();

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.webmanifest': 'application/manifest+json'
};

let ventana = null;
let servidor = null;

/* ---------- Servidor local (sirve la carpeta /app por http) ---------- */
function iniciarServidor() {
  return new Promise((resolve, reject) => {
    servidor = http.createServer((req, res) => {
      let url = decodeURIComponent((req.url || '/').split('?')[0]);
      if (url === '/' || url === '') url = '/index.html';
      const ruta = path.normalize(path.join(RAIZ, url));
      if (!ruta.startsWith(RAIZ)) { res.writeHead(403); return res.end(); }
      fs.readFile(ruta, (err, data) => {
        if (err) { res.writeHead(404); return res.end('No encontrado'); }
        res.writeHead(200, {
          'Content-Type': MIME[path.extname(ruta).toLowerCase()] || 'application/octet-stream',
          'Cache-Control': 'no-cache'
        });
        res.end(data);
      });
    });
    servidor.on('error', reject);
    servidor.listen(PUERTO, '127.0.0.1', () => resolve());
  });
}

/* ---------- Configuración de impresión ---------- */
function rutaConfig() { return path.join(app.getPath('userData'), 'impresion.json'); }
function leerConfig() {
  try { return Object.assign({ impresora: '', anchoMm: 0 }, JSON.parse(fs.readFileSync(rutaConfig(), 'utf8'))); }
  catch (e) { return { impresora: '', anchoMm: 0 }; }
}
function guardarConfig(cfg) {
  const limpia = {
    impresora: String((cfg && cfg.impresora) || ''),
    anchoMm: [58, 80].includes(Number(cfg && cfg.anchoMm)) ? Number(cfg.anchoMm) : 0
  };
  fs.writeFileSync(rutaConfig(), JSON.stringify(limpia, null, 2), 'utf8');
  return limpia;
}

/* ---------- Impresión SILENCIOSA (sin cuadro de diálogo) ---------- */
function opcionesBase(cfg) {
  const o = { silent: true, printBackground: true, margins: { marginType: 'none' } };
  if (cfg.impresora) o.deviceName = cfg.impresora;   // si está vacío usa la predeterminada de Windows
  return o;
}

function imprimirHTML(html) {
  return new Promise((resolve) => {
    const cfg = leerConfig();
    const archivo = path.join(os.tmpdir(), 'smartapps-ticket-' + Date.now() + '.html');
    try { fs.writeFileSync(archivo, String(html || ''), 'utf8'); }
    catch (e) { return resolve({ ok: false, error: 'No se pudo preparar el ticket' }); }

    const w = new BrowserWindow({
      show: false,
      webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false }
    });
    const cerrar = () => {
      try { w.destroy(); } catch (e) {}
      try { fs.unlinkSync(archivo); } catch (e) {}
    };

    w.webContents.on('did-fail-load', () => { cerrar(); resolve({ ok: false, error: 'No se pudo cargar el ticket' }); });
    w.webContents.on('did-finish-load', async () => {
      try {
        await new Promise((r) => setTimeout(r, 200));      // deja que termine de acomodar el ticket
        const opciones = opcionesBase(cfg);
        if (cfg.anchoMm > 0) {
          // Papel de rollo: ancho fijo y alto según el contenido (medidas en micrones)
          const altoPx = await w.webContents.executeJavaScript('Math.ceil(document.documentElement.scrollHeight)');
          opciones.pageSize = { width: cfg.anchoMm * 1000, height: Math.max(60000, Math.round(altoPx * 264.583) + 15000) };
        }
        w.webContents.print(opciones, (ok, motivo) => { cerrar(); resolve({ ok, error: ok ? null : motivo }); });
      } catch (e) { cerrar(); resolve({ ok: false, error: String(e) }); }
    });
    w.loadFile(archivo);
  });
}

ipcMain.handle('imprimir:html', (e, html) => imprimirHTML(html));
ipcMain.handle('imprimir:pagina', (e) => new Promise((resolve) => {
  e.sender.print(opcionesBase(leerConfig()), (ok, motivo) => resolve({ ok, error: ok ? null : motivo }));
}));
ipcMain.handle('impresoras:listar', async () => {
  try { return ventana ? await ventana.webContents.getPrintersAsync() : []; } catch (e) { return []; }
});
ipcMain.handle('impresion:config:get', () => leerConfig());
ipcMain.handle('impresion:config:set', (e, cfg) => guardarConfig(cfg));

/* ---------- Ventana principal ---------- */
function crearVentana() {
  ventana = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 500,
    show: false,
    backgroundColor: '#f3f4f6',
    title: 'SmartApps PDV',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false
    }
  });
  ventana.maximize();
  ventana.once('ready-to-show', () => ventana.show());
  ventana.loadURL('http://127.0.0.1:' + PUERTO + '/');

  // Enlaces externos se abren en el navegador; nunca ventanas nuevas dentro de la app
  ventana.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url) && url.indexOf('http://127.0.0.1:' + PUERTO) !== 0) shell.openExternal(url);
    return { action: 'deny' };
  });

  // Atajos: F11 pantalla completa, Ctrl + / - / 0 zoom (F5 y F6 quedan libres para el PDV)
  ventana.webContents.on('before-input-event', (ev, input) => {
    if (input.type !== 'keyDown') return;
    const wc = ventana.webContents;
    if (input.key === 'F11') { ventana.setFullScreen(!ventana.isFullScreen()); ev.preventDefault(); return; }
    if (MODO_DEV && input.key === 'F12') { wc.toggleDevTools(); ev.preventDefault(); return; }
    if (!input.control) return;
    const z = wc.getZoomLevel();
    if (input.key === '+' || input.key === '=') { wc.setZoomLevel(Math.min(z + 0.5, 3)); ev.preventDefault(); }
    else if (input.key === '-') { wc.setZoomLevel(Math.max(z - 0.5, -3)); ev.preventDefault(); }
    else if (input.key === '0') { wc.setZoomLevel(0); ev.preventDefault(); }
  });

  // Si por algún error se cae la página, se recarga sola
  ventana.webContents.on('render-process-gone', () => { try { ventana.reload(); } catch (e) {} });
  ventana.on('closed', () => { ventana = null; });
}

/* ---------- Arranque ---------- */
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (ventana) { if (ventana.isMinimized()) ventana.restore(); ventana.focus(); }
  });

  app.whenReady().then(async () => {
    Menu.setApplicationMenu(null);
    // Cámara (escáner) y portapapeles permitidos; nada más
    session.defaultSession.setPermissionRequestHandler((wc, permiso, cb) => {
      cb(['media', 'clipboard-read', 'clipboard-sanitized-write', 'fullscreen'].includes(permiso));
    });
    try {
      await iniciarServidor();
    } catch (e) {
      dialog.showErrorBox('SmartApps PDV', 'No se pudo iniciar la aplicación (el puerto ' + PUERTO + ' está ocupado).\nCierra otras copias de SmartApps PDV e inténtalo de nuevo.');
      return app.quit();
    }
    crearVentana();
  });

  app.on('window-all-closed', () => { try { servidor && servidor.close(); } catch (e) {} app.quit(); });
}
