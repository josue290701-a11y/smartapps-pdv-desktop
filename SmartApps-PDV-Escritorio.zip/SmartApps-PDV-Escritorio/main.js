// SmartApps PDV - app de escritorio (Electron 22, compatible con Windows 7 SP1)
const { app, BrowserWindow, ipcMain, Menu, dialog, shell, session } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const https = require('https');
const zlib = require('zlib');

// Dirección de tu PDV en internet. Al abrir la app (y cada 30 min) se descarga de aquí el
// index.html más reciente; así los cambios que subas al link llegan solos a la app de escritorio.
const URL_PDV = 'https://josue290701-a11y.github.io/Smartapps-PDV-App/';
const INTERVALO_REVISION_MS = 30 * 60 * 1000;

// Puerto FIJO: el origen (http://127.0.0.1:47831) no debe cambiar nunca,
// porque ahí se guardan la sesión de Firebase y los datos locales de la tienda.
const PUERTO = 47831;
const RAIZ = path.join(__dirname, 'app');
const MODO_DEV = process.argv.includes('--dev');

// Si la pantalla sale en blanco o con fallas en una PC vieja, abre la app con --sin-gpu
if (process.argv.includes('--sin-gpu')) app.disableHardwareAcceleration();

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.webmanifest': 'application/manifest+json'
};

let ventana = null;
let servidor = null;

/* ---------- Actualización automática del PDV ---------- */
// La copia descargada se guarda en la carpeta de datos del usuario (no se pierde al cerrar la app).
// Si no hay internet o la descarga falla, se usa la última copia buena o la que trae el instalador.
function rutaIndexActualizado() { return path.join(app.getPath('userData'), 'app-actualizada', 'index.html'); }
function rutaIndexServido() {
  const alt = rutaIndexActualizado();
  return fs.existsSync(alt) ? alt : path.join(RAIZ, 'index.html');
}

function descargarTexto(url, redirecciones) {
  return new Promise((resolve, reject) => {
    if (redirecciones > 3) return reject(new Error('demasiadas redirecciones'));
    const req = https.get(url, { headers: { 'User-Agent': 'SmartApps-PDV-Escritorio', 'Cache-Control': 'no-cache' }, timeout: 8000 }, (res) => {
      if ([301, 302, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        return resolve(descargarTexto(new URL(res.headers.location, url).toString(), redirecciones + 1));
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      const partes = [];
      res.on('data', (d) => partes.push(d));
      res.on('end', () => resolve(Buffer.concat(partes).toString('utf8')));
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
  });
}

// Solo se acepta una página que de verdad sea el PDV completo con soporte de escritorio
// (no un error 404, ni un archivo a medias, ni la versión web sin impresión directa)
function htmlValido(html) {
  return typeof html === 'string' && html.length > 100000 &&
    html.indexOf('SMARTAPPS PDV') !== -1 &&
    html.indexOf('electronAPI') !== -1 &&   // debe traer el puente de impresión de escritorio; si no, se conserva la versión actual
    /<\/html>\s*$/i.test(html);
}

// Devuelve true si se descargó una versión distinta a la que se está usando
async function buscarActualizacion() {
  try {
    const html = await descargarTexto(URL_PDV + '?v=' + Date.now(), 0);
    if (!htmlValido(html)) return false;
    let actual = '';
    try { actual = fs.readFileSync(rutaIndexServido(), 'utf8'); } catch (e) {}
    if (actual === html) return false;
    const archivo = rutaIndexActualizado();
    fs.mkdirSync(path.dirname(archivo), { recursive: true });
    fs.writeFileSync(archivo + '.tmp', html, 'utf8');
    fs.renameSync(archivo + '.tmp', archivo);
    return true;
  } catch (e) { return false; }
}

let actualizacionPendiente = false;
async function ofrecerRecarga() {
  if (!ventana || !actualizacionPendiente) return;
  let ocupado = true;
  try { ocupado = await ventana.webContents.executeJavaScript('(typeof carrito!=="undefined" && carrito.length>0)'); } catch (e) {}
  if (ocupado) return;   // no interrumpir una venta en curso; se vuelve a intentar en la siguiente revisión
  actualizacionPendiente = false;
  const r = await dialog.showMessageBox(ventana, {
    type: 'info', buttons: ['Actualizar ahora', 'Más tarde'], defaultId: 0, cancelId: 1,
    title: 'SmartApps PDV', message: 'Hay una nueva versión del PDV.',
    detail: 'Si eliges "Más tarde", se aplicará la próxima vez que abras la app.'
  });
  if (r.response === 0) { try { ventana.webContents.reloadIgnoringCache(); } catch (e) {} }
}

function iniciarRevisionPeriodica() {
  setInterval(async () => {
    if (await buscarActualizacion()) actualizacionPendiente = true;
    await ofrecerRecarga();
  }, INTERVALO_REVISION_MS);
}

/* ---------- Servidor local (sirve la carpeta /app por http) ---------- */
function iniciarServidor() {
  return new Promise((resolve, reject) => {
    servidor = http.createServer((req, res) => {
      let url = decodeURIComponent((req.url || '/').split('?')[0]);
      if (url === '/' || url === '') url = '/index.html';
      let ruta = path.normalize(path.join(RAIZ, url));
      if (!ruta.startsWith(RAIZ)) { res.writeHead(403); return res.end(); }
      if (url === '/index.html') ruta = rutaIndexServido();   // usa la versión descargada si existe
      fs.readFile(ruta, (err, data) => {
        if (err) { res.writeHead(404); return res.end('No encontrado'); }
        res.writeHead(200, {
          'Content-Type': MIME[path.extname(ruta).toLowerCase()] || 'application/octet-stream',
          'Cache-Control': 'no-cache'
        });
        res.end(data);
      });
    });
    servidor.on('error', reject);
    servidor.listen(PUERTO, '127.0.0.1', () => resolve());
  });
}

/* ---------- Configuración de impresión ---------- */
function rutaConfig() { return path.join(app.getPath('userData'), 'impresion.json'); }
function leerConfig() {
  try { return Object.assign({ impresora: '', anchoMm: 0 }, JSON.parse(fs.readFileSync(rutaConfig(), 'utf8'))); }
  catch (e) { return { impresora: '', anchoMm: 0 }; }
}
function guardarConfig(cfg) {
  const limpia = {
    impresora: String((cfg && cfg.impresora) || ''),
    anchoMm: [58, 80].includes(Number(cfg && cfg.anchoMm)) ? Number(cfg.anchoMm) : 0
  };
  fs.writeFileSync(rutaConfig(), JSON.stringify(limpia, null, 2), 'utf8');
  return limpia;
}

/* ---------- Impresión SILENCIOSA (sin cuadro de diálogo) ---------- */
function opcionesBase(cfg) {
  const o = { silent: true, printBackground: true, margins: { marginType: 'none' } };
  if (cfg.impresora) o.deviceName = cfg.impresora;   // si está vacío usa la predeterminada de Windows
  return o;
}

function imprimirHTML(html) {
  return new Promise((resolve) => {
    const cfg = leerConfig();
    const archivo = path.join(os.tmpdir(), 'smartapps-ticket-' + Date.now() + '.html');
    try { fs.writeFileSync(archivo, String(html || ''), 'utf8'); }
    catch (e) { return resolve({ ok: false, error: 'No se pudo preparar el ticket' }); }

    const w = new BrowserWindow({
      show: false,
      webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false }
    });
    const cerrar = () => {
      try { w.destroy(); } catch (e) {}
      try { fs.unlinkSync(archivo); } catch (e) {}
    };

    w.webContents.on('did-fail-load', () => { cerrar(); resolve({ ok: false, error: 'No se pudo cargar el ticket' }); });
    w.webContents.on('did-finish-load', async () => {
      try {
        await new Promise((r) => setTimeout(r, 200));      // deja que termine de acomodar el ticket
        const opciones = opcionesBase(cfg);
        if (cfg.anchoMm > 0) {
          // Papel de rollo: ancho fijo y alto según el contenido (medidas en micrones)
          const altoPx = await w.webContents.executeJavaScript('Math.ceil(document.documentElement.scrollHeight)');
          opciones.pageSize = { width: cfg.anchoMm * 1000, height: Math.max(60000, Math.round(altoPx * 264.583) + 15000) };
        }
        w.webContents.print(opciones, (ok, motivo) => { cerrar(); resolve({ ok, error: ok ? null : motivo }); });
      } catch (e) { cerrar(); resolve({ ok: false, error: String(e) }); }
    });
    w.loadFile(archivo);
  });
}

ipcMain.handle('imprimir:html', (e, html) => imprimirHTML(html));
ipcMain.handle('imprimir:pagina', (e) => new Promise((resolve) => {
  e.sender.print(opcionesBase(leerConfig()), (ok, motivo) => resolve({ ok, error: ok ? null : motivo }));
}));
ipcMain.handle('impresoras:listar', async () => {
  try { return ventana ? await ventana.webContents.getPrintersAsync() : []; } catch (e) { return []; }
});
ipcMain.handle('impresion:config:get', () => leerConfig());
ipcMain.handle('impresion:config:set', (e, cfg) => guardarConfig(cfg));

/* ---------- Respaldos automáticos ---------- */
// Se guardan comprimidos en Documentos\SmartApps-Respaldos y se conservan los últimos 30.
function carpetaRespaldos() { return path.join(app.getPath('documents'), 'SmartApps-Respaldos'); }
ipcMain.handle('respaldo:guardar', async (e, nombre, contenido) => {
  try {
    const dir = carpetaRespaldos();
    fs.mkdirSync(dir, { recursive: true });
    const seguro = String(nombre || 'respaldo.json.gz').replace(/[^A-Za-z0-9._-]/g, '_');
    const ruta = path.join(dir, seguro);
    fs.writeFileSync(ruta + '.tmp', zlib.gzipSync(Buffer.from(String(contenido), 'utf8')));
    fs.renameSync(ruta + '.tmp', ruta);
    const viejos = fs.readdirSync(dir).filter((f) => /^respaldo-\d{4}-\d{2}-\d{2}-.*\.json\.gz$/.test(f)).sort();
    while (viejos.length > 30) { try { fs.unlinkSync(path.join(dir, viejos.shift())); } catch (er) {} }
    return { ok: true, ruta: ruta };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  }
});
ipcMain.handle('respaldo:abrirCarpeta', async () => {
  const dir = carpetaRespaldos();
  fs.mkdirSync(dir, { recursive: true });
  await shell.openPath(dir);
  return { ok: true, ruta: dir };
});

/* ---------- Ventana principal ---------- */
function crearVentana() {
  ventana = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 500,
    show: false,
    backgroundColor: '#f3f4f6',
    title: 'SmartApps PDV',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false
    }
  });
  ventana.maximize();
  ventana.once('ready-to-show', () => ventana.show());
  ventana.loadURL('http://127.0.0.1:' + PUERTO + '/');

  // Enlaces externos se abren en el navegador; nunca ventanas nuevas dentro de la app
  ventana.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url) && url.indexOf('http://127.0.0.1:' + PUERTO) !== 0) shell.openExternal(url);
    return { action: 'deny' };
  });

  // Atajos: F11 pantalla completa, Ctrl + / - / 0 zoom (F5 y F6 quedan libres para el PDV)
  ventana.webContents.on('before-input-event', (ev, input) => {
    if (input.type !== 'keyDown') return;
    const wc = ventana.webContents;
    if (input.key === 'F11') { ventana.setFullScreen(!ventana.isFullScreen()); ev.preventDefault(); return; }
    if (MODO_DEV && input.key === 'F12') { wc.toggleDevTools(); ev.preventDefault(); return; }
    if (!input.control) return;
    const z = wc.getZoomLevel();
    if (input.key === '+' || input.key === '=') { wc.setZoomLevel(Math.min(z + 0.5, 3)); ev.preventDefault(); }
    else if (input.key === '-') { wc.setZoomLevel(Math.max(z - 0.5, -3)); ev.preventDefault(); }
    else if (input.key === '0') { wc.setZoomLevel(0); ev.preventDefault(); }
  });

  // Si por algún error se cae la página, se recarga sola
  ventana.webContents.on('render-process-gone', () => { try { ventana.reload(); } catch (e) {} });
  ventana.on('closed', () => { ventana = null; });
}

/* ---------- Arranque ---------- */
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (ventana) { if (ventana.isMinimized()) ventana.restore(); ventana.focus(); }
  });

  app.whenReady().then(async () => {
    Menu.setApplicationMenu(null);
    // Cámara (escáner) y portapapeles permitidos; nada más
    session.defaultSession.setPermissionRequestHandler((wc, permiso, cb) => {
      cb(['media', 'clipboard-read', 'clipboard-sanitized-write', 'fullscreen'].includes(permiso));
    });
    // Antes de abrir: busca la versión más reciente del PDV (máx. 6 s; sin internet sigue de inmediato)
    try { await Promise.race([buscarActualizacion(), new Promise((r) => setTimeout(r, 6000))]); } catch (e) {}
    try {
      await iniciarServidor();
    } catch (e) {
      dialog.showErrorBox('SmartApps PDV', 'No se pudo iniciar la aplicación (el puerto ' + PUERTO + ' está ocupado).\nCierra otras copias de SmartApps PDV e inténtalo de nuevo.');
      return app.quit();
    }
    crearVentana();
    iniciarRevisionPeriodica();
  });

  app.on('window-all-closed', () => { try { servidor && servidor.close(); } catch (e) {} app.quit(); });
}
