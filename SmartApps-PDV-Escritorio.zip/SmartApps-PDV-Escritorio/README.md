# SmartApps PDV – App de escritorio (Windows 7 / 10 / 11)

Es tu mismo PDV (carpeta `app/`) dentro de una ventana propia, con **impresión directa sin cuadro de diálogo**.
Usa Electron 22, la última versión que funciona en **Windows 7 SP1**.

## 1) Crear el instalador (en una PC con Windows 10/11 y con internet)
1. Instala Node.js LTS desde https://nodejs.org
2. Abre una terminal dentro de esta carpeta y ejecuta:
   ```
   npm install
   npm start        (para probarla)
   npm run dist     (genera los instaladores)
   ```
3. En la carpeta `dist/` quedan dos instaladores:
   - `SmartApps-PDV-Setup-1.0.0-x64.exe`  → Windows de 64 bits
   - `SmartApps-PDV-Setup-1.0.0-ia32.exe` → Windows de 32 bits
   (En la PC con Windows 7: Inicio → clic derecho en Equipo → Propiedades → "Tipo de sistema".)

> El instalador **no se puede crear dentro de Windows 7** (Node moderno no corre ahí). Solo se instala.

### Alternativa sin PC: crear el instalador en línea (GitHub Actions)
1. Crea un repositorio nuevo y **privado** en GitHub.
2. Sube este `.zip` sin descomprimir (Add file → Upload files).
3. Crea el archivo `.github/workflows/build.yml` con el flujo que te dio Claude (Add file → Create new file).
4. Pestaña **Actions** → "Crear instalador" → **Run workflow**. Tarda unos minutos.
5. Abre la ejecución terminada y descarga **SmartApps-PDV-Instaladores** (contiene los dos .exe).

## 2) Instalar en la PC de la tienda
1. Copia el instalador con una USB y ejecútalo. Necesita **Windows 7 con Service Pack 1**.
2. Abre **SmartApps PDV** desde el acceso directo del escritorio.
3. Entra a **Config. del ticket → Impresión (app de escritorio)**, elige tu impresora y presiona **Imprimir prueba**.
   - Si el ticket sale cortado, cambia **Ancho del papel** a 58 mm u 80 mm.

## Cosas útiles
- **F11**: pantalla completa. **Ctrl + / Ctrl -**: zoom. **F5 y F6** son del PDV.
- Si la pantalla sale en blanco o con fallas (PC muy vieja): agrega `--sin-gpu` al acceso directo.
- Los datos locales de esta app son **independientes de los de Chrome**. Antes de cambiar, confirma que no
  haya ventas pendientes de sincronizar con Firebase.
- La primera vez abre la app con internet (carga las librerías de Firebase). Después puede iniciar sin internet.
- Para actualizar el PDV: reemplaza `app/index.html` y vuelve a ejecutar `npm run dist`.
