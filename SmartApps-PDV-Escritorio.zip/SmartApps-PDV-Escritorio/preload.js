// Puente seguro entre la página (tu PDV) y Electron.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  esEscritorio: true,
  imprimirHTML: (html) => ipcRenderer.invoke('imprimir:html', html),
  imprimirPagina: () => ipcRenderer.invoke('imprimir:pagina'),
  listarImpresoras: () => ipcRenderer.invoke('impresoras:listar'),
  obtenerConfigImpresion: () => ipcRenderer.invoke('impresion:config:get'),
  guardarConfigImpresion: (cfg) => ipcRenderer.invoke('impresion:config:set', cfg),
  guardarRespaldo: (nombre, contenido) => ipcRenderer.invoke('respaldo:guardar', nombre, contenido),
  abrirCarpetaRespaldos: () => ipcRenderer.invoke('respaldo:abrirCarpeta')
});
